﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcGames.Data;
using MvcGames.Models;

namespace MvcMovie.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new MvcGamesContext(
            serviceProvider.GetRequiredService<
                DbContextOptions<MvcGamesContext>>()))
        {
            // Look for any movies.
            if (context.Game.Any())
            {
                return;   // DB has been seeded
            }
            context.Game.AddRange(
                new Game
                {
                    Id = "1",
                    Name = "Elden Ring",
                    ReleaseDate = DateTime.Parse("2022-2-25"),
                    Genre = "Souls Like",
                    Price = 7.99M
                },
                new Game
                {
                    Id = "2",
                    Name = "Gran Turismo ",
                    ReleaseDate = DateTime.Parse("2022-3-4"),
                    Genre = "Racing",
                    Price = 8.99M
                },
                new Game
                {
                    Id = "3",
                    Name = "Hollow Knight 2",
                    ReleaseDate = DateTime.Parse("2017-2-24"),
                    Genre = "Comedy",
                    Price = 9.99M
                }
            ) ;
            context.SaveChanges();
        }
    }
}